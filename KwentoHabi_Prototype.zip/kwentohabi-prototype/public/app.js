(function () {
  'use strict';

  var LEVELS = {
    strict: { label: 'Strict', note: 'Default for junior high. Flags mild and graphic violence.' },
    moderate: { label: 'Moderate', note: 'Flags graphic violence only.' },
    literature: { label: 'Literature study', note: 'No automatic flags, so works like Noli Me Tangere can be read in context.' }
  };
  var MIN_NOTE = 12;
  var fmt = new Intl.DateTimeFormat('en-PH', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: 'Asia/Manila' });

  // server data lives on `state` alongside UI-only fields
  var state = { loaded: false, tab: 'student', busy: false, notice: '', error: '', editing: {}, editDraft: {}, merging: {}, draft: '', newAuthor: null,
    users: [], chapters: [], result: { contradictions: [], flags: [] }, notes: {}, resolutions: {}, flagDecisions: {}, log: [], level: 'strict' };
  var AUTH = {};
  var noteTimers = {};

  /* ---------- api ---------- */
  function api(method, url, body) {
    return fetch(url, { method: method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (!r.ok) throw new Error(j.error || 'Request failed (' + r.status + ')');
          return j;
        });
      });
  }
  function apply(s) {
    var keep = state.notes;
    Object.keys(s).forEach(function (k) { state[k] = s[k]; });
    AUTH = {};
    state.users.forEach(function (u) { AUTH[u.id] = { name: u.name, first: u.name.split(' ')[0], cls: u.cls }; });
    if (!state.newAuthor && state.users.length) state.newAuthor = state.users[0].id;
    if (!s.notes) state.notes = keep;
    state.loaded = true;
  }
  function run(fn) {
    state.error = '';
    return Promise.resolve().then(fn).then(function () { render(); }).catch(function (e) {
      state.error = e && e.message ? e.message : 'Something went wrong.';
      render();
    });
  }
  function load() { return api('GET', '/api/state').then(apply); }

  /* ---------- helpers ---------- */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function chap(id) { return state.chapters.find(function (c) { return c.id === id; }); }
  function words(t) { return t.trim().split(/\s+/).filter(Boolean).length; }
  function when(iso) { return fmt.format(new Date(iso)); }
  function chip(id) {
    var a = AUTH[id] || { first: '?', name: id, cls: 'a' };
    return '<span class="chip ' + a.cls + '"><span class="dot" aria-hidden="true">' + esc(a.first[0]) + '</span>' + esc(a.name) + '</span>';
  }
  function statusOf(key) {
    var r = state.resolutions[key];
    if (!r) return 'open';
    return r.type === 'teacher' ? 'teacher' : 'resolved';
  }
  function isActive(key) { return statusOf(key) !== 'resolved'; }
  function findC(key) { return state.result.contradictions.find(function (c) { return c.key === key; }); }
  function ready(c) {
    var n = state.notes[c.key] || {};
    var la = chap(c.a.chapter).author, lb = chap(c.b.chapter).author;
    return (n[la] || '').trim().length >= MIN_NOTE && (n[lb] || '').trim().length >= MIN_NOTE;
  }
  function visibleFlags() {
    return state.result.flags.filter(function (f) {
      if (f.category === 'self-harm' || f.category === 'distress') return true;
      if (state.level === 'literature') return false;
      if (state.level === 'moderate') return f.severity === 'graphic';
      return true;
    });
  }
  function sideLabel(c, which) { var s = c[which]; return AUTH[chap(s.chapter).author].first + "'s " + s.value; }
  function flushNotes(c) {
    var n = state.notes[c.key] || {};
    var who = [chap(c.a.chapter).author, chap(c.b.chapter).author];
    return Promise.all(who.map(function (w) {
      clearTimeout(noteTimers[c.key + w]);
      return api('POST', '/api/notes', { key: c.key, who: w, text: n[w] || '' });
    }));
  }

  /* ---------- views ---------- */
  function chapterBody(ch) {
    var ranges = [];
    function idx(q) {
      if (!q) return -1;
      var k = ch.text.indexOf(q);
      return k >= 0 ? k : ch.text.toLowerCase().indexOf(q.toLowerCase());
    }
    state.result.contradictions.forEach(function (c) {
      [c.a, c.b].forEach(function (s) {
        if (s.chapter !== ch.id) return;
        var k = idx(s.quote);
        if (k >= 0) ranges.push({ s: k, e: k + s.quote.length, cls: statusOf(c.key) === 'resolved' ? 'hl-ok' : 'hl-open' });
      });
    });
    visibleFlags().forEach(function (f) {
      if (f.chapter !== ch.id || state.flagDecisions[f.key] === 'allow') return;
      var k = idx(f.quote);
      if (k >= 0) ranges.push({ s: k, e: k + f.quote.length, cls: 'hl-flag' });
    });
    ranges.sort(function (x, y) { return x.s - y.s; });
    var out = '', pos = 0;
    ranges.forEach(function (r) {
      if (r.s < pos) return;
      out += esc(ch.text.slice(pos, r.s)) + '<mark class="' + r.cls + '">' + esc(ch.text.slice(r.s, r.e)) + '</mark>';
      pos = r.e;
    });
    return out + esc(ch.text.slice(pos));
  }

  function chapterCard(ch) {
    var paused = state.result.contradictions.filter(function (c) {
      return isActive(c.key) && (c.a.chapter === ch.id || c.b.chapter === ch.id);
    });
    var flagged = visibleFlags().some(function (f) { return f.chapter === ch.id && state.flagDecisions[f.key] !== 'allow'; });
    var editing = !!state.editing[ch.id];
    return '<article class="card">' +
      '<div class="card-head">' + chip(ch.author) + '<span class="mono">' + esc(when(ch.at)) + ' · ' + words(ch.text) + ' words</span></div>' +
      '<h3>' + esc(ch.title) + '</h3>' +
      (editing
        ? '<textarea class="story-edit" id="edit-' + esc(ch.id) + '" data-edit="' + esc(ch.id) + '" aria-label="Edit ' + esc(ch.title) + '">' + esc(state.editDraft[ch.id] != null ? state.editDraft[ch.id] : ch.text) + '</textarea>' +
          '<div class="row"><button class="btn small primary" data-action="save-edit" data-id="' + esc(ch.id) + '">Save chapter</button><button class="btn small" data-action="cancel-edit" data-id="' + esc(ch.id) + '">Cancel</button></div>'
        : '<p class="story-text">' + chapterBody(ch) + '</p>' +
          '<div class="row"><button class="btn small" data-action="edit" data-id="' + esc(ch.id) + '">Edit chapter</button></div>') +
      (paused.length ? '<div class="row">' + paused.map(function (c) {
        return '<span class="pill open">Thread paused: ' + esc(c.subject + ' ' + c.attribute) + '</span>';
      }).join('') + '</div>' : '') +
      (flagged ? '<p class="notice info">Part of this chapter is with your teacher. You can rework the underlined line or ask your teacher about it. Nothing was deleted.</p>' : '') +
      '</article>';
  }

  function addForm() {
    var opts = state.users.map(function (u) {
      return '<option value="' + esc(u.id) + '"' + (state.newAuthor === u.id ? ' selected' : '') + '>' + esc(u.name) + '</option>';
    }).join('');
    return '<div class="card"><h3>Add a chapter</h3>' +
      '<div class="row"><label for="newAuthor" class="label">Writing as</label><select id="newAuthor">' + opts + '</select></div>' +
      '<textarea id="newText" class="story-edit" placeholder="Write the next part of the story here." aria-label="New chapter text">' + esc(state.draft) + '</textarea>' +
      '<div class="row"><button class="btn primary" data-action="add">Add chapter</button><span class="muted" style="font-size:13px">The checker flags and asks. It never rewrites what you wrote.</span></div></div>';
  }

  function contradictionCard(c, i) {
    var ca = chap(c.a.chapter), cb = chap(c.b.chapter);
    var st = statusOf(c.key), r = state.resolutions[c.key];
    var pill = st === 'open' ? '<span class="pill open">Open</span>' : st === 'teacher' ? '<span class="pill info">With teacher</span>' : '<span class="pill ok">Resolved</span>';
    function ver(s, ch) {
      return '<div class="ver">' + chip(ch.author) + '<span class="mono">' + esc(ch.title.split(':')[0]) + ' · ' + esc(when(ch.at)) + '</span>' +
        '<q>' + esc(s.quote) + '</q><span class="val">' + esc(s.value) + '</span></div>';
    }
    var body = '';
    if (st === 'resolved') {
      body = '<div class="steps"><p class="notice info" style="background:var(--ok-bg);color:var(--ok)">' + esc(r.summary) + '</p></div>';
    } else if (st === 'teacher') {
      body = '<div class="steps"><p class="notice info">Waiting for your teacher to decide. Switch to Teacher view to see how they will answer.</p></div>';
    } else {
      var n = state.notes[c.key] || {};
      var A = ca.author, B = cb.author;
      var noteBox = function (me, other, mine, theirs) {
        var starters = ['I see that ' + AUTH[other].first + ' wrote ' + theirs + '. ', 'I imagined ' + mine + ' because ', 'We could make both fit if '];
        return '<div class="note-box">' + chip(me) +
          '<textarea id="note-' + i + '-' + me + '" data-note="' + esc(c.key) + '" data-who="' + esc(me) + '" data-i="' + i + '" rows="3" placeholder="Start with their version, then explain yours." aria-label="Perspective note from ' + esc(AUTH[me].name) + '">' + esc(n[me] || '') + '</textarea>' +
          '<div class="starters">' + starters.map(function (s) {
            return '<button type="button" data-action="starter" data-i="' + i + '" data-who="' + esc(me) + '" data-text="' + esc(s) + '">' + esc(s.trim().slice(0, 30)) + (s.trim().length > 30 ? '…' : '') + '</button>';
          }).join('') + '</div></div>';
      };
      var gate = '<div data-gate="' + i + '"' + (ready(c) ? '' : ' hidden') + ' class="steps" style="border-top:0;padding-top:0">' +
        '<span class="label">Step 2 · Choose a resolution</span>' +
        (state.merging[c.key]
          ? '<div class="radio"><input type="radio" id="m-' + i + '-a" name="m-' + i + '" value="a" checked><label for="m-' + i + '-a">Use ' + esc(sideLabel(c, 'a')) + '</label></div>' +
            '<div class="radio"><input type="radio" id="m-' + i + '-b" name="m-' + i + '" value="b"><label for="m-' + i + '-b">Use ' + esc(sideLabel(c, 'b')) + '</label></div>' +
            '<div class="row"><button class="btn primary small" data-action="merge-confirm" data-i="' + i + '">Confirm merge</button><button class="btn small" data-action="merge-cancel" data-i="' + i + '">Back</button></div>'
          : '<div class="row"><button class="btn" data-action="merge-open" data-i="' + i + '">Merge into one version</button>' +
            '<button class="btn" data-action="keep-both" data-i="' + i + '">Keep both on purpose</button>' +
            '<button class="btn" data-action="ask-teacher" data-i="' + i + '">Ask the teacher</button></div>') +
        '</div>';
      body = '<div class="steps"><p><b>Was this on purpose?</b> <span class="muted">If a narrator is unreliable, you can keep both. Only this thread is paused, so the rest of the story keeps moving.</span></p>' +
        '<span class="label">Step 1 · Perspective notes</span><div class="notes">' + noteBox(A, B, c.a.value, c.b.value) + noteBox(B, A, c.b.value, c.a.value) + '</div>' + gate + '</div>';
    }
    return '<article class="card" data-card="' + i + '"><div class="card-head"><h3>' + esc(c.subject + ' · ' + c.attribute) + '</h3>' + pill + '</div>' +
      '<div class="versions">' + ver(c.a, ca) + ver(c.b, cb) + '</div>' + body + '</article>';
  }

  function studentView() {
    var cons = state.result.contradictions;
    var open = cons.filter(function (c) { return isActive(c.key); }).length;
    var via = state.via === 'claude' ? 'Checked by Claude' : 'Checked with built-in demo rules';
    var head = '<div class="sec-head"><h2>Continuity</h2>' +
      '<button class="btn primary" data-action="check"' + (state.busy ? ' disabled' : '') + '>' + (state.busy ? 'Checking…' : 'Check continuity') + '</button></div>';
    var meta = '<p class="mono" aria-live="polite">' + (state.busy ? 'Comparing all chapters across authors. This can take up to a minute with Claude.' :
      esc(via) + ' · ' + state.chapters.length + ' chapters · ' + esc(when(state.checkedAt)) + (state.claudeConfigured ? '' : ' · No API key set')) + '</p>';
    var notice = (state.notice ? '<p class="notice warn">' + esc(state.notice) + '</p>' : '') +
      (state.stale ? '<p class="notice warn">Chapters changed since the last check. Press Check continuity to compare again.</p>' : '');
    var list = cons.length
      ? '<p><b>' + cons.length + ' contradiction' + (cons.length === 1 ? '' : 's') + ' between authors</b> <span class="muted">· ' + open + ' still open</span></p>' + cons.map(contradictionCard).join('')
      : '<div class="card"><p><b>No contradictions between authors.</b></p><p class="muted">Every fact the checker found agrees across chapters.</p></div>';
    return '<main class="grid"><section class="col"><div class="sec-head"><h2>Story so far</h2><span class="mono">Class story: ' + esc(state.story || '') + '</span></div>' +
      state.chapters.map(chapterCard).join('') + addForm() + '</section>' +
      '<section class="col">' + head + meta + notice + list + '</section></main>';
  }

  function statusPill(key) {
    var st = statusOf(key);
    return st === 'open' ? '<span class="pill open">Open</span>' : st === 'teacher' ? '<span class="pill info">Waiting for teacher</span>' : '<span class="pill ok">Resolved</span>';
  }

  function teacherView() {
    var cons = state.result.contradictions;
    var open = cons.filter(function (c) { return isActive(c.key); }).length;
    var vf = visibleFlags();
    var pending = vf.filter(function (f) { return !state.flagDecisions[f.key]; }).length;
    var totalWords = state.chapters.reduce(function (n, c) { return n + words(c.text); }, 0) || 1;

    var stats = '<div class="stats">' +
      '<div class="stat"><b>' + state.chapters.length + '</b><span class="muted">chapters</span></div>' +
      '<div class="stat"><b>' + open + '</b><span class="muted">contested facts open</span></div>' +
      '<div class="stat"><b>' + (cons.length - open) + '</b><span class="muted">resolved by students or you</span></div>' +
      '<div class="stat"><b>' + pending + '</b><span class="muted">passages to review</span></div></div>';

    var rows = cons.length ? cons.map(function (c) {
      var decide = statusOf(c.key) === 'teacher'
        ? '<div class="row" style="margin-top:6px"><button class="btn small" data-action="teacher-decide" data-key="' + esc(c.key) + '" data-choice="a">Use ' + esc(AUTH[chap(c.a.chapter).author].first) + '</button>' +
          '<button class="btn small" data-action="teacher-decide" data-key="' + esc(c.key) + '" data-choice="b">Use ' + esc(AUTH[chap(c.b.chapter).author].first) + '</button>' +
          '<button class="btn small" data-action="teacher-decide" data-key="' + esc(c.key) + '" data-choice="both">Keep both</button></div>' : '';
      return '<tr><td><b>' + esc(c.subject) + '</b><br><span class="muted">' + esc(c.attribute) + '</span></td>' +
        '<td><div>' + chip(chap(c.a.chapter).author) + ' wrote <b>' + esc(c.a.value) + '</b></div><div style="margin-top:4px">' + chip(chap(c.b.chapter).author) + ' wrote <b>' + esc(c.b.value) + '</b></div></td>' +
        '<td>' + statusPill(c.key) + decide + '</td></tr>';
    }).join('') : '<tr><td colspan="3" class="muted">No contested facts. Run a check from the student view.</td></tr>';

    var contrib = state.users.map(function (u) {
      var mine = state.chapters.filter(function (c) { return c.author === u.id; });
      var w = mine.reduce(function (n, c) { return n + words(c.text); }, 0);
      var last = mine.length ? when(mine[mine.length - 1].at) : 'none yet';
      return '<div class="contrib"><span>' + chip(u.id) + '</span><div class="bar ' + esc(u.cls) + '" style="width:' + Math.max(4, Math.round(w / totalWords * 100)) + '%" role="img" aria-label="' + esc(u.name) + ' wrote ' + w + ' of ' + totalWords + ' words"></div>' +
        '<span class="mono">' + mine.length + ' ch · ' + w + ' words · last ' + esc(last) + '</span></div>';
    }).join('');

    var levels = '<div class="levels">' + Object.keys(LEVELS).map(function (k) {
      return '<button class="level-opt" data-action="level" data-level="' + k + '" aria-pressed="' + (state.level === k) + '"><b>' + esc(LEVELS[k].label) + '</b><span class="muted" style="font-size:13px">' + esc(LEVELS[k].note) + '</span></button>';
    }).join('') + '</div>';

    var flagList = vf.length ? vf.map(function (f) {
      var ch = chap(f.chapter), d = state.flagDecisions[f.key];
      var dist = f.category === 'distress' || f.category === 'self-harm';
      return '<div class="card"><div class="card-head">' + chip(ch.author) + '<span class="pill ' + (dist ? 'open' : 'info') + '">' + esc(f.category + ' · ' + f.severity) + '</span></div>' +
        '<p class="story-text">' + esc(f.quote) + '</p>' +
        (dist ? '<p class="notice warn">Route to the guidance counselor. The tool does not diagnose or punish.</p>' : '') +
        (d ? '<p class="mono">Your decision: ' + (d === 'allow' ? 'allowed as is' : 'student asked to rework') + '</p>'
           : '<div class="row"><button class="btn small" data-action="flag" data-key="' + esc(f.key) + '" data-d="allow">Allow as is</button><button class="btn small" data-action="flag" data-key="' + esc(f.key) + '" data-d="rework">Ask student to rework</button></div>') + '</div>';
    }).join('') : '<div class="card"><p class="muted">Nothing is flagged at the ' + esc(LEVELS[state.level].label.toLowerCase()) + ' level. The AI flags and you decide, so flagged lines are never deleted automatically.</p></div>';

    var log = state.log.length ? '<ul class="log">' + state.log.map(function (l) {
      return '<li><span class="mono">' + esc(when(l.at)) + '</span><span>' + esc(l.text) + '</span></li>';
    }).join('') + '</ul>' : '<p class="muted">No resolutions yet. They appear here when students merge, keep both, or ask you.</p>';

    return '<main class="col" style="gap:28px">' + stats +
      '<section class="col"><h2>Contested facts</h2><div class="table-wrap"><table><thead><tr><th>Fact</th><th>Versions</th><th>Status</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>' +
      '<section class="col"><div class="sec-head"><h2>Who wrote what</h2><span class="mono">Group-level record, shown by words contributed</span></div><div class="card">' + contrib + '</div></section>' +
      '<section class="col"><h2>Content level</h2>' + levels + '</section>' +
      '<section class="col"><h2>Passages to review</h2>' + flagList + '</section>' +
      '<section class="col"><h2>Resolution log</h2>' + log + '</section></main>';
  }

  function render() {
    var root = document.getElementById('app');
    if (!state.loaded) { root.innerHTML = '<p class="muted" style="padding-top:24px">' + esc(state.error || 'Loading…') + '</p>'; return; }
    var top = '<header class="top"><div class="brand"><h1>KwentoHabi</h1><p class="muted">Prototype · class story "' + esc(state.story || '') + '"</p></div>' +
      '<nav class="seg" aria-label="View"><button data-action="tab" data-tab="student" aria-pressed="' + (state.tab === 'student') + '">Student view</button>' +
      '<button data-action="tab" data-tab="teacher" aria-pressed="' + (state.tab === 'teacher') + '">Teacher view</button></nav></header><div class="weave" aria-hidden="true"></div>' +
      (state.error ? '<p class="notice warn" role="alert" style="margin-bottom:16px">' + esc(state.error) + '</p>' : '');
    var foot = '<details><summary>About this prototype</summary>' +
      '<p>Everything you do is saved on the server in data/db.json, so chapters, perspective notes, resolutions, the content level and the teacher log survive a restart. The continuity check uses Claude when ANTHROPIC_API_KEY is set, and falls back to a small set of demo rules (eye color, hair color, hometown, age, siblings) otherwise.</p>' +
      '<p>There is no sign-in yet. Student and teacher views are two screens of one demo class, and student text is never rewritten.</p>' +
      '<div class="row" style="margin-top:10px"><button class="btn small" data-action="reset">Reset demo data</button></div></details>';
    var focusId = document.activeElement && document.activeElement.id;
    root.innerHTML = top + (state.tab === 'student' ? studentView() : teacherView()) + foot;
    if (focusId) { var f = document.getElementById(focusId); if (f && f.focus) f.focus(); }
  }

  /* ---------- events ---------- */
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-action]');
    if (!t) return;
    var act = t.dataset.action;
    var i = t.dataset.i != null ? +t.dataset.i : -1;
    var c = i >= 0 ? state.result.contradictions[i] : null;

    if (act === 'tab') { state.tab = t.dataset.tab; render(); }
    else if (act === 'edit') { state.editing[t.dataset.id] = true; render(); }
    else if (act === 'cancel-edit') { delete state.editing[t.dataset.id]; delete state.editDraft[t.dataset.id]; render(); }
    else if (act === 'save-edit') {
      var id = t.dataset.id;
      run(function () {
        var ta = document.getElementById('edit-' + id);
        return api('PUT', '/api/chapters', { id: id, text: ta ? ta.value : '' }).then(function (s) {
          apply(s); delete state.editing[id]; delete state.editDraft[id];
        });
      });
    }
    else if (act === 'add') {
      run(function () {
        return api('POST', '/api/chapters', { author: state.newAuthor, text: state.draft }).then(function (s) { state.draft = ''; state.notice = ''; apply(s); });
      });
    }
    else if (act === 'check') {
      state.busy = true; state.notice = ''; render();
      api('POST', '/api/check').then(function (s) { state.notice = s.notice || ''; apply(s); })
        .catch(function (err) { state.error = err.message; })
        .then(function () { state.busy = false; render(); });
    }
    else if (act === 'starter') {
      var ta2 = document.getElementById('note-' + i + '-' + t.dataset.who);
      if (ta2) { ta2.value = (ta2.value ? ta2.value + ' ' : '') + t.dataset.text; ta2.focus(); ta2.dispatchEvent(new Event('input', { bubbles: true })); }
    }
    else if (act === 'merge-open') { state.merging[c.key] = true; render(); }
    else if (act === 'merge-cancel') { delete state.merging[c.key]; render(); }
    else if (act === 'merge-confirm' || act === 'keep-both' || act === 'ask-teacher') {
      var type = act === 'merge-confirm' ? 'merged' : act === 'keep-both' ? 'both' : 'teacher';
      var pick = document.querySelector('input[name="m-' + i + '"]:checked');
      run(function () {
        return flushNotes(c).then(function () {
          return api('POST', '/api/resolve', { key: c.key, type: type, choice: pick ? pick.value : 'a' });
        }).then(function (s) { delete state.merging[c.key]; apply(s); });
      });
    }
    else if (act === 'teacher-decide') {
      run(function () { return api('POST', '/api/teacher/decide', { key: t.dataset.key, choice: t.dataset.choice }).then(apply); });
    }
    else if (act === 'level') {
      run(function () { return api('POST', '/api/settings', { level: t.dataset.level }).then(apply); });
    }
    else if (act === 'flag') {
      run(function () { return api('POST', '/api/flags', { key: t.dataset.key, decision: t.dataset.d }).then(apply); });
    }
    else if (act === 'reset') {
      run(function () { return api('POST', '/api/reset').then(function (s) { state.notes = {}; state.merging = {}; state.editing = {}; state.notice = ''; apply(s); }); });
    }
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t.dataset && t.dataset.note) {
      var key = t.dataset.note, who = t.dataset.who;
      (state.notes[key] = state.notes[key] || {})[who] = t.value;
      var c = findC(key);
      var gate = document.querySelector('[data-gate="' + t.dataset.i + '"]');
      if (gate && c) gate.hidden = !ready(c);
      clearTimeout(noteTimers[key + who]);
      noteTimers[key + who] = setTimeout(function () {
        api('POST', '/api/notes', { key: key, who: who, text: t.value }).catch(function () {});
      }, 500);
    } else if (t.dataset && t.dataset.edit) { state.editDraft[t.dataset.edit] = t.value; }
    else if (t.id === 'newText') { state.draft = t.value; }
  });
  document.addEventListener('change', function (e) {
    if (e.target.id === 'newAuthor') state.newAuthor = e.target.value;
  });

  load().then(render).catch(function (e) { state.error = 'Could not reach the server: ' + e.message; render(); });
})();
