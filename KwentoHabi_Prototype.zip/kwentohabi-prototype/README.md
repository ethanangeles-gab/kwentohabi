# KwentoHabi prototype

A working prototype of KwentoHabi's main feature: checking a group story for contradictions between different student authors, with a student resolution flow and a teacher dashboard.

## Run it

You need Node 18 or newer. There is nothing to install.

```
node server.js
```

Open http://localhost:3000.

## Use Claude for the check (optional)

```
cp .env.example .env
```

Put your key in `ANTHROPIC_API_KEY`. Without a key the app still runs, using small demo rules that cover eye color, hair color, hometown, age and siblings. The page tells you which engine ran each check.

## What to try

1. **Student view.** Three chapters by three authors already conflict on Lia's eye color, siblings and hometown. Press Check continuity.
2. Each contradiction shows both lines, the authors and the times. Both authors write a short perspective note, which unlocks the three choices: merge into one version, keep both on purpose, or ask the teacher. Only that thread is paused.
3. **Add a chapter** as any author, press Check continuity, and see what it catches. Try "Lia was 12 years old." in one chapter and "Lia was 14 years old." in another.
4. **Teacher view.** Answer the questions students sent you, set the content level (strict, moderate, literature study), allow or send back flagged passages, and read the resolution log.

Everything is saved to `data/db.json`. "Reset demo data" at the bottom restores the sample class.

## Tests

```
npm test
```

Starts the real server on a temporary folder and runs 19 checks against the API: conflict detection, the notes-before-resolution rule, teacher decisions, persistence, path traversal and reset.

## Layout

```
server.js        HTTP server, JSON storage, REST API
lib/checker.js   Claude check and the offline demo rules
public/          Front end (index.html, app.js, styles.css)
data/seed.json   The sample class and story
test/smoke.js    End-to-end API test
```

## API

| Method and path | Purpose |
| --- | --- |
| GET /api/state | Everything the front end needs |
| POST /api/chapters | Add a chapter `{author, text, title?}` |
| PUT /api/chapters | Edit a chapter `{id, text}` |
| POST /api/check | Run the continuity and content check |
| POST /api/notes | Save a perspective note `{key, who, text}` |
| POST /api/resolve | Student resolution `{key, type: merged\|both\|teacher, choice?}` |
| POST /api/teacher/decide | Teacher decision `{key, choice: a\|b\|both}` |
| POST /api/settings | Content level `{level}` |
| POST /api/flags | Allow or rework a flagged passage `{key, decision}` |
| POST /api/reset | Restore the demo data |

## What is still a prototype

- No sign-in. Student and teacher are two screens of one demo class, and anyone can act as anyone.
- One class and one story, stored in a single JSON file. A real version needs a database, accounts, teacher-scoped classes and guardian consent.
- Student writing is sent to the Anthropic API when a key is set. Before real students use it, check data privacy obligations (RA 10173) and the consent flow in your Business Model Canvas.
- No teacher-materials upload, story wiki, GCash or licensing yet. This prototype covers the cross-author continuity checker only.
- The demo rules are a fallback, not the product. The Claude check is what handles real student writing.
