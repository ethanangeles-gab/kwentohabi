'use strict';
// KwentoHabi prototype server. No dependencies: Node 18+ only.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { localCheck, claudeCheck } = require('./lib/checker');

// tiny .env reader (so there is nothing to install)
try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch (_) { /* no .env, fine */ }

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const SEED_FILE = path.join(__dirname, 'data', 'seed.json');
const PUBLIC = path.join(__dirname, 'public');
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
const MIN_NOTE = 12;

// ---------- storage ----------
let db;
function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
function applyResult(res, via) {
  for (const f of res.flags) f.key = f.chapter + '|' + f.quote;
  db.result = res; db.via = via; db.checkedAt = new Date().toISOString(); db.stale = false;
}
function loadDb() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) fs.copyFileSync(SEED_FILE, DB_FILE);
  db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  if (!db.checkedAt) { applyResult(localCheck(db.chapters), 'demo'); save(); }
}
function resetDb() {
  fs.copyFileSync(SEED_FILE, DB_FILE);
  loadDb();
}

// ---------- helpers ----------
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const user = (id) => db.users.find((u) => u.id === id);
const chap = (id) => db.chapters.find((c) => c.id === id);
const first = (id) => (user(id) || { name: id }).name.split(' ')[0];
const findC = (key) => db.result.contradictions.find((c) => c.key === key);
const addLog = (text) => db.log.unshift({ at: new Date().toISOString(), text });
const publicState = () => ({ ...db, claudeConfigured: !!process.env.ANTHROPIC_API_KEY });
function clean(v, max) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim().slice(0, max); }
function cleanText(v, max) { return String(v == null ? '' : v).replace(/\r/g, '').trim().slice(0, max); }
function notesReady(c) {
  const n = db.notes[c.key] || {};
  const la = chap(c.a.chapter).author, lb = chap(c.b.chapter).author;
  return (n[la] || '').trim().length >= MIN_NOTE && (n[lb] || '').trim().length >= MIN_NOTE;
}

// ---------- API ----------
const routes = {
  'GET /api/state': () => publicState(),

  'POST /api/chapters': (b) => {
    if (!user(b.author)) throw new HttpError(400, 'Unknown author.');
    const text = cleanText(b.text, 4000);
    if (!text) throw new HttpError(400, 'Write something in the chapter first.');
    const n = db.chapters.length + 1;
    db.chapters.push({ id: 'c' + Date.now().toString(36), author: b.author, title: clean(b.title, 80) || 'Chapter ' + n, at: new Date().toISOString(), text });
    db.stale = true; save();
    return publicState();
  },

  'PUT /api/chapters': (b) => {
    const ch = chap(b.id);
    if (!ch) throw new HttpError(404, 'Chapter not found.');
    const text = cleanText(b.text, 4000);
    if (!text) throw new HttpError(400, 'A chapter cannot be empty.');
    if (text !== ch.text) { ch.text = text; db.stale = true; save(); }
    return publicState();
  },

  'POST /api/check': async () => {
    let res = null, via = 'demo', notice = '';
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (apiKey) {
      try {
        res = await claudeCheck(db.chapters, db.users, { apiKey, model: MODEL, signal: AbortSignal.timeout(120000) });
        via = 'claude';
      } catch (e) {
        console.error('[check] Claude failed:', e.message);
        notice = 'Claude could not finish the check, so the built-in demo rules ran instead.';
      }
    } else {
      notice = 'No ANTHROPIC_API_KEY is set, so the built-in demo rules ran. Add a key to .env to use Claude.';
    }
    applyResult(res || localCheck(db.chapters), via);
    save();
    return { ...publicState(), notice };
  },

  'POST /api/notes': (b) => {
    const c = findC(b.key);
    if (!c) throw new HttpError(404, 'That contradiction is no longer open.');
    const allowed = [chap(c.a.chapter).author, chap(c.b.chapter).author];
    if (!allowed.includes(b.who)) throw new HttpError(400, 'Only the two authors write perspective notes.');
    (db.notes[c.key] = db.notes[c.key] || {})[b.who] = cleanText(b.text, 600);
    save();
    return { ok: true };
  },

  'POST /api/resolve': (b) => {
    const c = findC(b.key);
    if (!c) throw new HttpError(404, 'That contradiction is no longer open.');
    if (!notesReady(c)) throw new HttpError(400, 'Both authors need to write a perspective note first (at least ' + MIN_NOTE + ' characters each).');
    const A = first(chap(c.a.chapter).author), B = first(chap(c.b.chapter).author);
    const what = c.subject + ' ' + c.attribute;
    let summary;
    if (b.type === 'merged') {
      const s = b.choice === 'b' ? c.b : c.a;
      summary = `${A} and ${B} merged on ${what}: ${s.value} (${first(chap(s.chapter).author)}'s version).`;
    } else if (b.type === 'both') {
      summary = `${A} and ${B} kept both versions of ${what} as an intentional difference in perspective.`;
    } else if (b.type === 'teacher') {
      summary = `${A} and ${B} asked the teacher about ${what}.`;
    } else throw new HttpError(400, 'Unknown resolution.');
    db.resolutions[c.key] = { type: b.type, summary, at: new Date().toISOString() };
    addLog(summary); save();
    return publicState();
  },

  'POST /api/teacher/decide': (b) => {
    const c = findC(b.key);
    if (!c) throw new HttpError(404, 'That contradiction is no longer open.');
    const what = c.subject + ' ' + c.attribute;
    let summary;
    if (b.choice === 'both') summary = `Teacher kept both versions of ${what}.`;
    else {
      const s = b.choice === 'b' ? c.b : c.a;
      summary = `Teacher decided ${what}: ${s.value} (${first(chap(s.chapter).author)}'s version).`;
    }
    db.resolutions[c.key] = { type: 'teacher-decided', summary, at: new Date().toISOString() };
    addLog(summary); save();
    return publicState();
  },

  'POST /api/settings': (b) => {
    if (!['strict', 'moderate', 'literature'].includes(b.level)) throw new HttpError(400, 'Unknown content level.');
    db.level = b.level; save();
    return publicState();
  },

  'POST /api/flags': (b) => {
    if (!db.result.flags.some((f) => f.key === b.key)) throw new HttpError(404, 'That passage is no longer flagged.');
    if (!['allow', 'rework'].includes(b.decision)) throw new HttpError(400, 'Unknown decision.');
    db.flagDecisions[b.key] = b.decision;
    addLog(b.decision === 'allow' ? 'Teacher allowed a flagged passage as is.' : 'Teacher asked a student to rework a flagged passage.');
    save();
    return publicState();
  },

  'POST /api/reset': () => { resetDb(); return publicState(); },
};

// ---------- http ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 200000) { reject(new HttpError(413, 'Request too large.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (_) { reject(new HttpError(400, 'Invalid JSON.')); }
    });
    req.on('error', reject);
  });
}
function send(res, status, body, type) {
  res.writeHead(status, { 'content-type': type || 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      const handler = routes[req.method + ' ' + url.pathname];
      if (!handler) return send(res, 404, { error: 'Not found.' });
      const body = req.method === 'GET' ? {} : await readBody(req);
      return send(res, 200, await handler(body));
    }
    if (req.method !== 'GET') return send(res, 405, { error: 'Method not allowed.' });
    const rel = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
    const file = path.normalize(path.join(PUBLIC, rel));
    if (!file.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Forbidden', 'text/plain');
    fs.readFile(file, (err, data) => {
      if (err) return send(res, 404, 'Not found', 'text/plain');
      send(res, 200, data, MIME[path.extname(file)] || 'application/octet-stream');
    });
  } catch (e) {
    if (!(e instanceof HttpError)) console.error(e);
    send(res, e.status || 500, { error: e instanceof HttpError ? e.message : 'Something went wrong on the server.' });
  }
});

loadDb();
server.listen(PORT, () => {
  console.log(`KwentoHabi running at http://localhost:${PORT}`);
  console.log(process.env.ANTHROPIC_API_KEY ? `Continuity check: Claude (${MODEL})` : 'Continuity check: demo rules (set ANTHROPIC_API_KEY in .env to use Claude)');
});
