'use strict';
// End-to-end smoke test: starts the real server on a temp data dir and drives the API.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const port = 3100 + Math.floor(Math.random() * 400);
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kwentohabi-'));
const base = 'http://localhost:' + port;
const env = { ...process.env, PORT: String(port), DATA_DIR: dir, ANTHROPIC_API_KEY: '' };
const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env, stdio: 'ignore' });

async function call(method, url, body) {
  const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, json: await r.json().catch(() => ({})) };
}
async function waitUp() {
  for (let i = 0; i < 50; i++) {
    try { await fetch(base + '/api/state'); return; } catch (_) { await new Promise((r) => setTimeout(r, 100)); }
  }
  throw new Error('server did not start');
}

(async () => {
  let passed = 0;
  const ok = (name) => { passed++; console.log('  ok  ' + name); };
  try {
    await waitUp();

    let s = (await call('GET', '/api/state')).json;
    assert.equal(s.chapters.length, 3); ok('seed loads with 3 chapters');
    const keys = s.result.contradictions.map((c) => c.key).sort();
    assert.deepEqual(keys, ['lia|eye color', 'lia|hometown', 'lia|siblings']); ok('finds eye color, hometown and siblings conflicts across authors');
    assert.ok(s.result.contradictions.every((c) => c.a.chapter !== c.b.chapter)); ok('every conflict spans two different chapters');
    assert.ok(s.result.flags.some((f) => f.severity === 'graphic') && s.result.flags.some((f) => f.severity === 'mild')); ok('flags mild and graphic violence');

    let r = await call('POST', '/api/resolve', { key: 'lia|eye color', type: 'both' });
    assert.equal(r.status, 400); ok('resolving without perspective notes is refused');

    await call('POST', '/api/notes', { key: 'lia|eye color', who: 'maria', text: 'I see that Jose wrote green eyes.' });
    r = await call('POST', '/api/resolve', { key: 'lia|eye color', type: 'both' });
    assert.equal(r.status, 400); ok('one note is not enough');
    r = await call('POST', '/api/notes', { key: 'lia|eye color', who: 'ana', text: 'I am not part of this conflict at all.' });
    assert.equal(r.status, 400); ok('only the two involved authors can write notes');

    await call('POST', '/api/notes', { key: 'lia|eye color', who: 'jose', text: 'I imagined green because of the sea light.' });
    r = await call('POST', '/api/resolve', { key: 'lia|eye color', type: 'merged', choice: 'b' });
    assert.equal(r.status, 200);
    assert.equal(r.json.resolutions['lia|eye color'].type, 'merged');
    assert.match(r.json.log[0].text, /green/); ok('merge works after both notes and is logged');

    await call('POST', '/api/notes', { key: 'lia|siblings', who: 'maria', text: 'I wanted two brothers for the village.' });
    await call('POST', '/api/notes', { key: 'lia|siblings', who: 'jose', text: 'I wanted her to feel lonely at school.' });
    r = await call('POST', '/api/resolve', { key: 'lia|siblings', type: 'teacher' });
    assert.equal(r.json.resolutions['lia|siblings'].type, 'teacher');
    r = await call('POST', '/api/teacher/decide', { key: 'lia|siblings', choice: 'both' });
    assert.equal(r.json.resolutions['lia|siblings'].type, 'teacher-decided'); ok('ask teacher, then teacher decides');

    r = await call('POST', '/api/chapters', { author: 'ana', text: 'Ana was 12 years old when the story began.' });
    assert.equal(r.json.chapters.length, 4); assert.equal(r.json.stale, true); ok('adding a chapter marks the check as stale');
    r = await call('POST', '/api/chapters', { author: 'nobody', text: 'x' });
    assert.equal(r.status, 400); ok('unknown author rejected');
    r = await call('POST', '/api/check');
    assert.equal(r.json.stale, false); assert.equal(r.json.via, 'demo'); assert.ok(r.json.notice); ok('re-check clears stale and reports demo engine without an API key');
    assert.equal(r.json.resolutions['lia|eye color'].type, 'merged'); ok('earlier resolutions survive a re-check');

    r = await call('POST', '/api/settings', { level: 'literature' });
    assert.equal(r.json.level, 'literature');
    r = await call('POST', '/api/settings', { level: 'bogus' });
    assert.equal(r.status, 400); ok('content level validates');

    const f = s.result.flags[0];
    r = await call('POST', '/api/flags', { key: f.key, decision: 'allow' });
    assert.equal(r.json.flagDecisions[f.key], 'allow'); ok('teacher can allow a flagged passage');

    const before = JSON.parse(fs.readFileSync(path.join(dir, 'db.json'), 'utf8'));
    assert.equal(before.chapters.length, 4); ok('state is persisted to disk');

    r = await fetch(base + '/..%2fserver.js'); assert.equal(r.status, 403);
    r = await fetch(base + '/%2e%2e/server.js'); assert.equal(r.status, 404); ok('static server blocks path traversal');
    r = await fetch(base + '/'); assert.equal(r.status, 200); ok('front end is served');

    r = await call('POST', '/api/reset');
    assert.equal(r.json.chapters.length, 3); assert.deepEqual(r.json.resolutions, {}); ok('reset restores the demo data');

    console.log('\n' + passed + ' checks passed');
  } catch (e) {
    console.error('\nFAILED:', e.message);
    process.exitCode = 1;
  } finally {
    srv.kill();
    fs.rmSync(dir, { recursive: true, force: true });
  }
})();
